﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TAF_WebServices.Scripted.api
{
    public class JsonClass
    {
        public String name;
        public String job;
    }
}