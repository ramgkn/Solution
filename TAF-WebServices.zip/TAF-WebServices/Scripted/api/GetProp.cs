﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Configuration;
using TAF_GenericUtility;


namespace TAF_WebServices.Scripted.api
{
    public class GetProp
    {
        public static string strDirPath = null;
        private static String cdir = ConfigDriver.getDirPath();
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Dictionary<String, String> getPropValues(String filename)
        {
            Dictionary<String, String> propMap = new Dictionary<String, String>();
            try
            {
                ExeConfigurationFileMap file = new ExeConfigurationFileMap();
                file.ExeConfigFilename = getDirPath() + filename +".config";
                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(file, ConfigurationUserLevel.None);
                AppSettingsSection appsection = (AppSettingsSection)config.GetSection("appSettings");
                foreach (string item in appsection.Settings.AllKeys)
                {
                    propMap.Add(item, appsection.Settings[item].Value);
                }
            }
            catch (Exception ex)
            {
                log.Error(String.Format("Key{0}：{1}/Message：{2}", filename, ex.Message, ex.StackTrace));
            }

            return propMap;

        }
        public static string getDirPath()
        {
            try
            {
                strDirPath = AppDomain.CurrentDomain.BaseDirectory.Substring(0,(AppDomain.CurrentDomain.BaseDirectory.IndexOf("bin")));
            }
            catch (Exception e)
            {
                log.Error(e);
            }
            return strDirPath;
        }
        public static String getFilePath(String fileName)
        {
            String filePath = cdir + "/" + fileName;
            if (File.Exists(filePath))
            {
                return filePath;
            }
            else return "";
        }
    }
}
