﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAFF_WEB_UTILS.Scripted.Web
{
    public class Generic_Web_Utilities
    {
        public static int RandomID(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static string ScreenShot_Capture(IWebDriver driver, string screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;
            Screenshot screenshot = ts.GetScreenshot();
            string pth = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));
            //string finalpth = folderpath + screenShotName + ".png";
            string finalpth = pth + @"\ExtentReport_Local\" + screenShotName + ".png";
            string localpath = new Uri(finalpth).LocalPath;

            screenshot.SaveAsFile(localpath, OpenQA.Selenium.ScreenshotImageFormat.Png);

            return localpath;
        }

        public static void HighlightElement(IWebElement element, IWebDriver driver)
        {
            var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"$(arguments[0]).css({ ""border-width"" : ""2px"", ""border-style"" : ""solid"", ""border-color"" : ""red"", ""background"" : ""yellow"" });";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
        }


    }
}
