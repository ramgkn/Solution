﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ScriptHelperClasses
{
    public static class LogGenerator
    {

        public static StringBuilder LogStringBuilder = new StringBuilder();
        //  public static String LogPath = System.Configuration.ConfigurationSettings.AppSettings["LogPath"];



        //private static string FileName = (USTHTMLUtil.BrowserUtil.ResultFolder).ToUpper() +"\\AutomationReportLog " + DateTime.Now.ToString("yyyyMMdd") + ".txt";
        //private static string FileName = (USTHTMLUtil.BrowserUtil.ResultFolder).ToUpper() + "\\AutomationReportLog " + DateTime.Now.ToString("yyyyMMdd") + ".txt";
        private static string FileName = "test.txt";
        //private static string Output = "";




        public static void StartTestCase(String TestCaseName)
        {
            

            DateTime dt = DateTime.Now;


            LogStringBuilder.Append(dt.ToString() + ":               " + "---------" + TestCaseName + "------" + "\r\n");
        }

        public static void EndTestCase(String TestCaseName)
        {
            DateTime dt = DateTime.Now;

            LogStringBuilder.Append(dt.ToString() + ":               " + "---------" + "--E-N-D--" + TestCaseName + "------" + "\r\n");
        }


        public static void Logger(String Log)
        {
            DateTime dt = DateTime.Now;
            LogStringBuilder.Append(dt.ToString() + ":               " + Log + "\r\n");
            GenerateLog();
        }

        public static void GenerateLog()
        {

            File.WriteAllText(FileName, LogStringBuilder.ToString());


        }

    }
}
