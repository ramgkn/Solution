﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;


namespace TAF_Web.Scripted.Web
{
    public class WebWaitHelper
    {
        
        public static Actions action = new Actions(LaunchBrowsers.driver);
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static TimeSpan getElementTimeout()
        {
            TimeSpan timeSpan = TimeSpan.FromSeconds(10);
            return timeSpan;
        }

        private static TimeSpan getPollingTimeoutInMilliSeconds()
        {
            TimeSpan timeSpan = TimeSpan.FromMilliseconds(30);
            return timeSpan;
        }

        private static DateTime getPollingTimeoutInDuration()
        {
            DateTime dateTime = new DateTime(0);
            return dateTime.AddMilliseconds(300);
        }

        private static TimeSpan getElementWaitTimeoutInDuration()
        {
            TimeSpan timeSpan = TimeSpan.FromSeconds(30);
            return timeSpan;
        }


        public static void waitForElement(IWebElement webEle)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, getElementWaitTimeoutInDuration());
                Func<IWebDriver, bool> waitForElement = new Func<IWebDriver, bool>((IWebDriver Web) =>
                {
                    IWebElement element = webEle;
                    By byEle = WebHandlers.webElementToBy(webEle);
                    waitForPresence(byEle, getElementTimeout());
                    //waitForNotStale(byEle, getElementTimeout());
                    scrollToElement(byEle);
                    waitForVisibleble(byEle, getElementTimeout());
                    waitForClickable(byEle, getElementTimeout());
                    return true;
                });

                wait.Until(waitForElement);
            }
            catch (Exception e)
            {
                log.Error(e);
            }

        }

        public static void waitForClear(IWebElement webEle)
        {

            try
            {
                WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, getElementWaitTimeoutInDuration());
                Func<IWebDriver, bool> waitForElement = new Func<IWebDriver, bool>((IWebDriver Web) =>
                {
                    IWebElement element = webEle;
                    By byEle = WebHandlers.webElementToBy(webEle);
                    waitForPresence(byEle, getElementTimeout());
                    //waitForNotStale(byEle, getElementTimeout());
                    scrollToElement(byEle);
                    waitForVisibleble(byEle, getElementTimeout());
                    waitForClickable(byEle, getElementTimeout());
                    return true;
                });

                wait.Until(waitForElement);
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }

        public static void waitForElementPresence(IWebElement webEle)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, getElementWaitTimeoutInDuration());
                Func<IWebDriver, bool> waitForElement = new Func<IWebDriver, bool>((IWebDriver Web) =>
                {
                    IWebElement element = webEle;
                    By byEle = WebHandlers.webElementToBy(webEle);
                    waitForPresence(byEle, getElementTimeout());
                    //waitForNotStale(byEle, getElementTimeout());
                    scrollToElement(byEle);
                    return true;
                });

                wait.Until(waitForElement);
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }

        public static void waitForPresence(By byEle, TimeSpan time)
        {
            WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, time);
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.PresenceOfAllElementsLocatedBy(byEle));
        }
        public static void waitForClickable(By byEle, TimeSpan time)
        {
            WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, getPollingTimeoutInMilliSeconds());
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(byEle));
        }
        public static void waitForVisibleble(By byEle, TimeSpan time)
        {
            WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, getPollingTimeoutInMilliSeconds());
            wait.Until(d => (SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(byEle)));
        }

        public static void waitForNotStale(By byEle, TimeSpan time)
        {
            WebDriverWait wait = new WebDriverWait(LaunchBrowsers.driver, time);
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.StalenessOf(LaunchBrowsers.driver.FindElement(byEle)));
        }
        public static void scrollToElement(By locator)
        {
            IWebElement element = LaunchBrowsers.driver.FindElement(locator);
            new Actions(LaunchBrowsers.driver).MoveToElement(element).MoveByOffset(element.Location.X, element.Location.Y).Click().Perform();
        }
    }
}
