﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TAFF_WEB_UTILS
{
    public class SeleniumContext
    {
        

        public SeleniumContext(BrowserType browserType,String DriverPath,[Optional] String NodeUrl)
        {   

            switch (browserType)
            {
                                
                case BrowserType.Chrome:
                    WebDriver = new ChromeDriver(DriverPath+@"\Drivers");
                    break;

                case BrowserType.Chrome_Headless:
                    WebDriver = new ChromeDriver(DriverPath + @"\Drivers");
                    ChromeOptions option = new ChromeOptions();
                    option.AddArgument("--headless");
                    WebDriver = new ChromeDriver(option);
                    break;

                case BrowserType.Firefox:
                    var driverDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                    FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(driverDir, "geckodriver.exe");
                    service.FirefoxBinaryPath = @"C:\Program Files\Mozilla Firefox\firefox.exe";//@"C:\Program Files (x86)\Mozilla Firefox\firefox.exe";
                    service.HideCommandPromptWindow = true;
                    service.SuppressInitialDiagnosticInformation = true;
                    WebDriver = new FirefoxDriver(service);
                    break;

                case BrowserType.IE:
                    break;

                case BrowserType.Chrome_Remote:
                    ChromeOptions options = new ChromeOptions();
                    //options.BinaryLocation = DriverPath + @"\Drivers\chromedriver.exe";
                    options.AddAdditionalCapability("browser", "Chrome", true);
                    WebDriver = new RemoteWebDriver(new Uri(NodeUrl), options);

                    break;
                    
                default:
                    WebDriver = new ChromeDriver(@"C:\Users\C62269A\Desktop\ParallelExecution\ParallelExecution\Drivers");
                    break;
                    //create the selenium context
            }


        }

        public enum BrowserType
        {
            Chrome,
            Chrome_Remote,
            Chrome_Headless,
            Firefox,
            IE
        }
        //public IWebDriver WebDriver { get; private set; }
        public RemoteWebDriver WebDriver { get; private set; }
    }
}
