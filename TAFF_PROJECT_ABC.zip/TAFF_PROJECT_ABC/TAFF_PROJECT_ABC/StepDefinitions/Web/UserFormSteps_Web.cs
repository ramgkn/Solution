﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium.Remote;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
//using ParallelExecution.Steps;
using TAFF_WEB_UTILS;

namespace TAFF_PROJECT_ABC
{
    [Binding]
    class UserFormSteps
    {
        private RemoteWebDriver _driver;

        public UserFormSteps(SeleniumContext seleniumContext)
        {
            this._driver = seleniumContext.WebDriver;
        }
                
        [Given(@"I start entering user form details like")]
        public void GivenIStartEnteringUserFormDetailsLike(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
            _driver.FindElement(By.Id("Initial")).SendKeys((string)data.Initial);
            _driver.FindElement(By.Id("FirstName")).SendKeys((string)data.FirstName);
            _driver.FindElement(By.Id("MiddleName")).SendKeys((string)data.MiddleName);
            _driver.FindElement(By.Name("english")).Click();
            Thread.Sleep(2000);
        }

        [Given(@"I click submit button")]
        public void GivenIClickSubmitButton()
        {
            _driver.FindElement(By.Name("Save")).Click();
        }

        [Given(@"I verify the entered user form details in the application database")]
        [Then(@"I verify the entered user form details in the application database")]



        public void GivenIVerifyTheEnteredUserFormDetailsInTheApplicationDatabase(Table table)
        {
            //Mock data collection
            //List<AUTDatabase> mockAUTData = new List<AUTDatabase>()
            //{
            //    new AUTDatabase()
            //    {
            //        FirstName = "Karthik",
            //        Initial = "k",
            //        MiddleName = "k"
            //    },

            //    new AUTDatabase()
            //    {
            //        FirstName = "Prashanth",
            //        Initial = "k",
            //        MiddleName = "k"
            //    }
            //};

            ////For verification with single row data
            //var result = table.FindAllInSet(mockAUTData);

            ////For verification againt Multiple row data
            //var resultnew = table.FindAllInSet(mockAUTData);

        }

        [Then(@"I logout of application")]
        public void ThenILogoutOfApplication()
        {
            //ScenarioContext.Current.Pending();
        }


    }

    public class AUTDatabase
    {
        public string Initial { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string Gender { get; set; }
    }



}
