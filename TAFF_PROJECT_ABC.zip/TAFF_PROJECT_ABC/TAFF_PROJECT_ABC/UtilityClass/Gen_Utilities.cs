﻿using System;
using OpenQA.Selenium;
using System.Drawing.Imaging;
using System.IO;

namespace TAFF_EXPERIAN_WEB_V01.UtilityClass
{
    class Gen_Utilities
    {
        public static int RandomID(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static string ScreenShot_Capture(IWebDriver driver, string screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;
            Screenshot screenshot = ts.GetScreenshot();
            string pth = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));
            //string finalpth = folderpath + screenShotName + ".png";
            string finalpth = pth + @"\ExtentReport_Local\" + screenShotName + ".png";
            string localpath = new Uri(finalpth).LocalPath;

            screenshot.SaveAsFile(localpath, OpenQA.Selenium.ScreenshotImageFormat.Png);

            return localpath;
        }

        public static void HighlightElement(IWebElement element, IWebDriver driver)
        {
            var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"$(arguments[0]).css({ ""border-width"" : ""2px"", ""border-style"" : ""solid"", ""border-color"" : ""red"", ""background"" : ""yellow"" });";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
        }
    }
}
