﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using NUnit.Framework;
using System.Runtime.InteropServices;
using System.IO;
using TAFF_EXPERIAN_WEB_V01.UtilityClass;

namespace TAFF_EXPERIAN_WEB_V01
{
    public class Database_Conn
    {
        public static string Con_Status = "Cannot open connection ! ";

        public static string Identifier;

        public static string DB_Write(String Query_Statement, Boolean Stored_Procedure)
        {

            string connetionString = Get_Connection_String();

            MySqlConnection cnn = new MySqlConnection(connetionString);

            MySqlCommand cmd;

            try
            {
                cnn.Open();

                cnn.Close();

                TestContext.Progress.WriteLine("DB Connection Initiated ! ");

                cmd = new MySqlCommand(Query_Statement, cnn);

                cmd.ExecuteNonQuery();

                cnn.Close();

                TestContext.Progress.WriteLine("DB Connection Closed ! ");

            }
            catch (Exception ex)
            {
                if (cnn.State == System.Data.ConnectionState.Open) { cnn.Close(); }

                Con_Status = "Cannot open connection ! " + ex;

            }


            return Con_Status;
        }
        public static string DB_StoredProcedure(string SP_Name, string[] Params, [Optional] Boolean CDB_Execution_Flag)
        {



            if (CDB_Execution_Flag == true)
            {

                string connetionString = Get_Connection_String();

                MySqlConnection cnn = new MySqlConnection(connetionString);

                MySqlCommand cmd;

                cmd = new MySqlCommand(SP_Name, cnn);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                switch (SP_Name.ToUpper())
                {
                    case "INSERT_RUN":

                        cmd.Parameters.Add(new MySqlParameter("projectId", Int64.Parse(Params[0])));

                        cmd.Parameters.Add(new MySqlParameter("runStatus", Params[1]));

                        cmd.Parameters.Add(new MySqlParameter("rundate", DateTime.Now));

                        cmd.Parameters.Add(new MySqlParameter("testApproach", Params[2]));

                        break;

                    case "GET_PROJECT_NAME":

                        cmd.Parameters.Add(new MySqlParameter("runId", Int64.Parse(Params[0])));

                        break;

                    case "CHECK_FEATURE_EXISTS":

                        cmd.Parameters.Add(new MySqlParameter("featurename", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("runId", Int64.Parse(Params[2])));

                        break;

                    case "INSERT_FEATURE":

                        cmd.Parameters.Add(new MySqlParameter("featurename", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("featuredesc", Params[1]));

                        cmd.Parameters.Add(new MySqlParameter("runId", Int64.Parse(Params[2])));

                        break;

                    case "INSERT_SCENARIO":

                        cmd.Parameters.Add(new MySqlParameter("scenarioname", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("scenariodesc", Params[1]));

                        cmd.Parameters.Add(new MySqlParameter("featureid", Int64.Parse(Params[2])));

                        cmd.Parameters.Add(new MySqlParameter("scenariobrowser", Params[3]));

                        break;

                    case "INSERT_SCENARIO_EXECUTION":

                        cmd.Parameters.Add(new MySqlParameter("executionTime", DateTime.Now));

                        cmd.Parameters.Add(new MySqlParameter("runId", Int64.Parse(Params[0])));

                        cmd.Parameters.Add(new MySqlParameter("featureId", Int64.Parse(Params[1])));

                        cmd.Parameters.Add(new MySqlParameter("scenarioId", Int64.Parse(Params[2])));

                        break;

                    case "INSERT_STEP":

                        cmd.Parameters.Add(new MySqlParameter("stepname", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("scenarioId", Int64.Parse(Params[1])));

                        break;

                    case "INSERT_STEP_EXECUTION":

                        cmd.Parameters.Add(new MySqlParameter("executionTime", DateTime.Now));

                        cmd.Parameters.Add(new MySqlParameter("keywordStatus", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("testcaseExecutionId", Params[1]));

                        cmd.Parameters.Add(new MySqlParameter("keywordId", Params[2]));

                        break;

                    case "UPDATE_SCENARIO_EXECUTION_STATUS":

                        cmd.Parameters.Add(new MySqlParameter("scenarioId", Int64.Parse(Params[0])));

                        cmd.Parameters.Add(new MySqlParameter("resultStatus", Params[1]));

                        break;

                    case "UPDATE_STEP_EXECUTION_STATUS":

                        cmd.Parameters.Add(new MySqlParameter("stepexecutionStatus", Params[0]));

                        cmd.Parameters.Add(new MySqlParameter("steperrormessage", Params[1]));

                        cmd.Parameters.Add(new MySqlParameter("stepId", Int64.Parse(Params[2])));

                        break;

                    case "INSERT_INTO_RUN":

                        cmd.Parameters.Add(new MySqlParameter("run_id", Int64.Parse(Params[0])));

                        cmd.Parameters.Add(new MySqlParameter("test_approach", Params[1]));

                        break;

                }

                cmd.Connection.Open();

                Console.WriteLine("Connection Established Wwith DB and SP " + SP_Name.ToUpper() + " initiated!!");

                object Db_Object = cmd.ExecuteScalar();

                if (Db_Object == null)
                {
                    Identifier = null;
                }
                else
                {
                    Identifier = Db_Object.ToString();
                }

                cnn.Close();

                Console.WriteLine("Connection Closed Wwith DB and SP " + SP_Name.ToUpper() + " Initiation Success!!");

                return Identifier;
            }
            else
            {
                return null;
            }


        }

        public static string Get_Connection_String()
        {

            string base_path = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));

            string config_path = ReadWriteConfigFile.GetXMLData(base_path + @"TAFF_Core_Config.xml", "dbconfig_file");

            string connetionString = ReadWriteConfigFile.GetXMLData(config_path + @"dbconfig.xml", "connection");

            string user_name = ReadWriteConfigFile.GetXMLData(config_path + @"dbconfig.xml", "username");

            string Pass_word = ReadWriteConfigFile.GetXMLData(config_path + @"dbconfig.xml", "password");

            string[] Conn_Str = connetionString.Split('/');

            string[] server = Conn_Str[2].Split(':');

            string d_base = Conn_Str[3];

            return "server=" + server[0] + ";database=" + Conn_Str[3] + ";Port=" + server[1] + ";uid=" + user_name + ";pwd=" + Pass_word + ";";

        }
    }
}
