﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Threading;

namespace TAFF_EXPERIAN_WEB_V01
{
    public class Batch_File_Trigger
    {
        public static void Run_Batch_File(String File_Path, String File_Name, [Optional] String RunID, [Optional] string Project_Name, [Optional] string hub)
        {
            System.Diagnostics.Process process = new System.Diagnostics.Process();

            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();

            //startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;

            startInfo.FileName = File_Path + File_Name;

            startInfo.Arguments = " " + RunID + " " + Project_Name + " " + hub;

            process.StartInfo = startInfo;

            process.Start();

            Thread.Sleep(500);

        }
    }
}
