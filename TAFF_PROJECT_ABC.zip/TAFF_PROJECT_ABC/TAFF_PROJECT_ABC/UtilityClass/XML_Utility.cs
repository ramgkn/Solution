﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace TAFF_EXPERIAN_WEB_V01.UtilityClass
{
    class ReadWriteConfigFile
    {
        public static string Nodeurl;

        public static string GetXMLData(string ConfigrationFilePath, string nodename)
        {
            try
            {
                XmlDocument xDoc = new XmlDocument();

                xDoc.Load(ConfigrationFilePath);

                string nodeValue = xDoc.DocumentElement.SelectSingleNode(nodename).InnerText;

                return nodeValue;
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);

                return null;
            }
        }
        public void UpdateXMLData(string ConfigrationFilePath, string nodename, string newValue)
        {

            try
            {

                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(ConfigrationFilePath);
                string nodeValue = xDoc.DocumentElement.SelectSingleNode(nodename).InnerText;
                xDoc.DocumentElement.SelectSingleNode(nodename).InnerText = newValue;
                xDoc.Save(ConfigrationFilePath);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
        }

        public static string GetNodeUrl(string ConfigrationFilePath, string _hubBrowser)
        {

            XmlDocument xDoc = new XmlDocument();

            xDoc.Load(ConfigrationFilePath);

            foreach (XmlElement xmlNode in xDoc.DocumentElement.FirstChild.LastChild.ChildNodes)
            {

                if (xmlNode.Attributes["browser"].Value.ToString() == _hubBrowser)
                {
                    Nodeurl = xmlNode.Attributes["url"].Value.ToString();
                    break;
                }
            }

            if (Nodeurl == null) Nodeurl = "http://10.215.202.41:7654/wd/hub";

            return Nodeurl;
        }

    }
}
