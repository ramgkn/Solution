﻿using BoDi;
using OpenQA.Selenium.Remote;
using TechTalk.SpecFlow;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter.Configuration;
using System;
using System.IO;
using TAFF_EXPERIAN_WEB_V01.UtilityClass;
using TAFF_EXPERIAN_WEB_V01;
using TAFF_WEB_UTILS;
using static TAFF_WEB_UTILS.SeleniumContext;

namespace TAFF_EXPERIAN_API_V01
{
    class SpecFlowHooks
    {

        [Binding]
        public class SpecFlow_Hooks
        {

            public static string Base_Path;
            public static String Project_Name;
            public static String RunID;
            public static string Step_Status;
            public static string Step_Comment;
            public static string CDB_Execution;
            public static string Feature_ID;
            public static string Scenario_ID;
            public static string Step_ID;
            public static string Node_URL;
            public static string Scenario_Status;
            public static string Scenario_Exec_ID;
            public static string hub_Browser;
            
            //Global Variable for Extend report
            private static ExtentTest featureName;
            private static ExtentTest scenario;
            private static AventStack.ExtentReports.ExtentReports extent;

            private readonly IObjectContainer _objectContainer;
            private readonly FeatureContext _featureContext;
            private static SeleniumContext seleniumContext;
            private readonly ScenarioContext _ScenarioContext;
            private RemoteWebDriver _driver;

            public SpecFlow_Hooks(IObjectContainer objectContainer, ScenarioContext ScenarioContext, FeatureContext featureContext)
            {
                _objectContainer = objectContainer;
                this._ScenarioContext = ScenarioContext;
                this._featureContext = featureContext;
            }

            [BeforeTestRun]
            public static void InitializeReport()
            {
                
                Base_Path = System.IO.Path.GetFullPath(Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, @"..\"));

                Project_Name = NUnit.Framework.TestContext.Parameters.Get("Project_Name");

                RunID = NUnit.Framework.TestContext.Parameters.Get("RunID");

                CDB_Execution = ReadWriteConfigFile.GetXMLData(Base_Path + @"TAFF_Core_Config.xml","CDB_Execution");

                if (RunID == "TAFF_BLANK" && Boolean.Parse(CDB_Execution) == true)
                    {
                        string project_id = ReadWriteConfigFile.GetXMLData(Base_Path + @"TAFF_Core_Config.xml", "project_id");

                        string[] Parameters = {project_id, "norun", "BDD-Specflow" };

                        RunID = Database_Conn.DB_StoredProcedure("INSERT_RUN", Parameters, Boolean.Parse(CDB_Execution));

                        string[] Parameters1 = { RunID };

                        Project_Name = Database_Conn.DB_StoredProcedure("GET_PROJECT_NAME", Parameters1, Boolean.Parse(CDB_Execution));
                                                
                    }

                Console.WriteLine("Execution In Progress For RunID: " + RunID + " Project Name: " + Project_Name);

                Node_URL = "http://10.215.200.176:5555/wd/hub";

                                
                ExtentV3HtmlReporter htmlReporter = new ExtentV3HtmlReporter(Base_Path + @"ExtentReport_Local\Local_Report_" + Project_Name + "_" + RunID + "_" + DateTime.Now.ToString("mm_dd_yyyy_HHMMss") + ".html");

                htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
                                
                extent = new AventStack.ExtentReports.ExtentReports();

                extent.AttachReporter(htmlReporter);
                                

                if (Boolean.Parse(CDB_Execution) == false)
                {
                    hub_Browser = "Chrome";

                    string config_path = ReadWriteConfigFile.GetXMLData(Base_Path + @"TAFF_Core_Config.xml", "dbconfig_file");

                    //Node_URL = ReadWriteConfigFile.GetNodeUrl(ReadWriteConfigFile.GetXMLData(Base_Path + @"TAFF_Core_Config.xml", "GridConfigFile"), hub_Browser.ToUpper());

                    //Batch_File_Trigger.Run_Batch_File(Base_Path + "Report_Utilities\\Grid_Start_Up\\", "Grid_StartUp.bat");

                    //Batch_File_Trigger.Run_Batch_File(Base_Path + "Report_Utilities\\Grid_Start_Up\\", "Grid_StartUp.bat");
                }

            }

            [BeforeFeature]
            public static void BeforeFeature()
            {
                
                seleniumContext = new SeleniumContext(BrowserType.Chrome, Base_Path, Node_URL);

            }

            
            [BeforeScenario]
            public void BeforeScenario()
            {
                Scenario_Status = "PASSED";

                _objectContainer.RegisterInstanceAs<SeleniumContext>(seleniumContext);
                
                _driver = seleniumContext.WebDriver;

                string[] Parameters = { _featureContext.FeatureInfo.Title, _featureContext.FeatureInfo.Description, RunID };

                Feature_ID = Database_Conn.DB_StoredProcedure("insert_feature", Parameters, Boolean.Parse(CDB_Execution));

                string[] Parameters1 = {_ScenarioContext.ScenarioInfo.Title,_ScenarioContext.ScenarioInfo.Description, Feature_ID, hub_Browser };

                Scenario_ID = Database_Conn.DB_StoredProcedure("insert_scenario", Parameters1, Boolean.Parse(CDB_Execution));

                string[] Parameters2 = { RunID, Feature_ID, Scenario_ID };

                Scenario_Exec_ID = Database_Conn.DB_StoredProcedure("INSERT_SCENARIO_EXECUTION", Parameters2, Boolean.Parse(CDB_Execution));

                featureName = extent.CreateTest<Feature>(_featureContext.FeatureInfo.Title);

                scenario = featureName.CreateNode<Scenario>(_ScenarioContext.ScenarioInfo.Title);

            }

            [BeforeStep]
            public void BeforeStep()
            {
                Step_Status = "PASSED";

                Step_Comment = "";

                string[] Parameters = {_ScenarioContext.StepContext.StepInfo.Text, Scenario_ID, _ScenarioContext.StepContext.StepInfo.StepDefinitionType.ToString() };
                
                Step_ID = Database_Conn.DB_StoredProcedure("insert_step", Parameters, Boolean.Parse(CDB_Execution));

                string[] Parameters2 = { Step_Status, Scenario_Exec_ID, Step_ID, _ScenarioContext.StepContext.StepInfo.StepDefinitionType.ToString() };

                Database_Conn.DB_StoredProcedure("insert_step_execution", Parameters2, Boolean.Parse(CDB_Execution));

                
            }


            [AfterStep]
            public void AfterStep()
            {
                
                var stepType = _ScenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();

                if (_ScenarioContext.TestError == null)
                {

                    if (stepType == "Given")
                        scenario.CreateNode<Given>(_ScenarioContext.StepContext.StepInfo.Text);
                    else if (stepType == "When")
                        scenario.CreateNode<When>(_ScenarioContext.StepContext.StepInfo.Text);
                    else if (stepType == "Then")
                        scenario.CreateNode<Then>(_ScenarioContext.StepContext.StepInfo.Text);
                    else if (stepType == "And")
                        scenario.CreateNode<And>(_ScenarioContext.StepContext.StepInfo.Text);
                }
                else if (_ScenarioContext.TestError != null)
                
                {
                    Step_Status = "FAILED";

                    if (stepType == "Given")
                    {
                        scenario.CreateNode<Given>(_ScenarioContext.StepContext.StepInfo.Text).Fail(_ScenarioContext.TestError.InnerException);//ScenarioContext.Current.TestError.InnerException);

                        Step_Comment = _ScenarioContext.TestError.InnerException.ToString();

                        scenario.AddScreenCaptureFromPath(Gen_Utilities.ScreenShot_Capture(_driver, "TEST"));

                        scenario.Log(Status.Fail, Step_Comment);

                    }
                    else if (stepType == "When")
                    {
                        scenario.CreateNode<When>(_ScenarioContext.StepContext.StepInfo.Text).Fail(_ScenarioContext.TestError.InnerException);//ScenarioContext.Current.TestError.InnerException);

                        Step_Comment = _ScenarioContext.TestError.InnerException.ToString();

                        scenario.AddScreenCaptureFromPath(Gen_Utilities.ScreenShot_Capture(_driver, "TEST"));

                        scenario.Log(Status.Fail, Step_Comment);

                    }
                    else if (stepType == "Then")
                    {
                        scenario.CreateNode<Then>(_ScenarioContext.StepContext.StepInfo.Text).Fail(_ScenarioContext.TestError.Message);//(ScenarioContext.Current.TestError.Message);

                        Step_Comment = _ScenarioContext.TestError.Message.ToString();

                        scenario.AddScreenCaptureFromPath(Gen_Utilities.ScreenShot_Capture(_driver, "TEST"));

                        scenario.Log(Status.Fail, Step_Comment);


                    }


            }

                if (_ScenarioContext.ScenarioExecutionStatus == ScenarioExecutionStatus.StepDefinitionPending)
                {
                  if (stepType == "Given")
                       scenario.CreateNode<Given>(_ScenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");
                  else if (stepType == "When")
                       scenario.CreateNode<When>(_ScenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");
                  else if (stepType == "Then")
                      scenario.CreateNode<Then>(_ScenarioContext.StepContext.StepInfo.Text).Skip("Step Definition Pending");

                }
            
                string[] Parameters = { Step_Status, Step_Comment, Step_ID, stepType };

                Database_Conn.DB_StoredProcedure("update_step_execution_status", Parameters, Boolean.Parse(CDB_Execution));
            }

            [AfterScenario]
            public void CleanUp()
            {
                string[] Parameters = { Scenario_ID, Scenario_Status };

                Database_Conn.DB_StoredProcedure("update_scenario_execution_status", Parameters, Boolean.Parse(CDB_Execution));

                _driver.Quit();

            }

            [AfterTestRun]
            public static void TearDownReport()
            {

                if (Boolean.Parse(CDB_Execution) == true)
                {
                    //string[] Parameters = { RunID,"BDD-Cucumber"};

                    //Database_Conn.DB_StoredProcedure("INSERT_INTO_RUN", Parameters, Local_Flag);      

                    Console.WriteLine("Initiating Java Report Utility!");

                    //Batch_File_Trigger.Run_Batch_File(Base_Path + "ReportUtilities\\", "Trigger_Report_Master.bat", RunID, Project_Name, Node_URL);

                    Console.WriteLine("Report Generation Complete For " + RunID);
                }
                else
                {
                    Console.WriteLine("RunID = " + RunID + " Project_Name= " + Project_Name);

                    //Flush report once test completes
                   extent.Flush();

                }

            }


        }

    }
        
}
